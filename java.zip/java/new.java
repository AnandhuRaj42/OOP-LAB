public class new
{
	public staitc ovid main(String args[])
	{
	System.out.println("Hello");
	}
}