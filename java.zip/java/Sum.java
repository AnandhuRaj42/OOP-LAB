import java.util.Scanner;
class sample
{
	int a,b,c;
	void cal()
	{
		c=a+b;
	}
	 void dis()
	{
		System.out.println("Sum="+c);
	}
}
public class Sum{
	public static void main(String args[])
	{
		sample s1=new sample();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a and b");
		s1.a=s.nextInt();
		s1.b=s.nextInt();
		System.out.println("a="+s1.a);
		System.out.println("b="+s1.b);
		s1.cal();
		s1.dis();
	}
}